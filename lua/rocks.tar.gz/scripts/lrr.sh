#!/usr/bin/env bash

luarocks --lua-version 5.1 --tree ~/.config/nvim/lua/.rocks remove "$1"
