return {
  "packer",

  "impatient",
  "filetype",

  "startup-time",
  "base16",

  "stickybuf",
  "stabilize",
  "unimpaired",

  "tmux-navigator",
}
