-- prevent builtin plugin loading
vim.g.loaded_netrwPlugin = true
