url = "leafo/moonscript-vim"

event = "VimEnter"
