url = "neoclide/jsonc.vim"

event = "VimEnter"
