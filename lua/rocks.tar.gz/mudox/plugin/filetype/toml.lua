url = "cespare/vim-toml"

branch = "main"

event = "VimEnter"
