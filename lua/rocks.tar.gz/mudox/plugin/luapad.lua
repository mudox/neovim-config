url = "rafcamlet/nvim-luapad"

-- cmd = {'LuaRun', 'LuaPad'}
