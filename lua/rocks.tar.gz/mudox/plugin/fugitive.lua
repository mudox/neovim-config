url = "tpope/vim-fugitive"

event = "VimEnter"
