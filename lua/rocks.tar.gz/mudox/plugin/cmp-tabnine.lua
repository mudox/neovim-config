url = "tzachar/cmp-tabnine"

run = "./install.sh"

event = "InsertEnter"
