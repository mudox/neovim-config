url = "folke/trouble.nvim"

requires = "kyazdani42/nvim-web-devicons"
