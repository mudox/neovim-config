url = "ggandor/lightspeed.nvim"

event = "BufRead"
