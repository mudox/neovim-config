url = "folke/twilight.nvim"

event = "VimEnter"
