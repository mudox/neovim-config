url = "honza/vim-snippets"

requires = "SirVer/ultisnips"

after = "ultisnips"

event = "VimEnter"
