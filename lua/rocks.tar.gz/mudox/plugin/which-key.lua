url = "folke/which-key.nvim"

opt = true -- `PackerLoad` by `mappings.lua`
