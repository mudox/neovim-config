url = "junegunn/vim-easy-align"

requires = "vim-repeat"

event = "BufRead"
