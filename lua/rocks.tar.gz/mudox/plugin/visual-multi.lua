url = "mg979/vim-visual-multi"

keys = { { "n", "<C-n>" }, { "i", "<C-n>" }, { "v", "<C-n>" } }
