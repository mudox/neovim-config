url = "neoclide/coc.nvim"

branch = "release"

event = "VimEnter"
