url = "luukvbaal/nnn.nvim"

keys = { "<M-/>n", "<M-/>N" }

cmd = { "NnnPicker", "NnnExplorer" }
