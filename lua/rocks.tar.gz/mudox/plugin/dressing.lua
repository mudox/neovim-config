url = "stevearc/dressing.nvim"

event = "VimEnter"
