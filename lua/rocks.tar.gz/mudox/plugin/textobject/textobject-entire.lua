url = "kana/vim-textobj-entire"

requires = "kana/vim-textobj-user"
