url = "wellle/targets.vim"

event = "VimEnter"
