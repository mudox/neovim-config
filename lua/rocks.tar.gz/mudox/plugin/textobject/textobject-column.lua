url = "coderifous/textobj-word-column.vim"

disable = true
