url = "antoinemadec/FixCursorHold.nvim"

config = function()
  vim.g.cursorhold_updatetime = 200
end
