url = "tweekmonster/startuptime.vim"

cmd = { "StartupTime" }
