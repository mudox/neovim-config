url = "folke/zen-mode.nvim"

keys = { { "n", "yoz" } }
