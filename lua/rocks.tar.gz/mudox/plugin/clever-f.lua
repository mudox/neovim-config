url = "rhysd/clever-f.vim"

keys = { "f", "F" }
