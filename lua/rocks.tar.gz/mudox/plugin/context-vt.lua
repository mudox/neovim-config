url = "haringsrob/nvim_context_vt"

requires = "nvim-treesitter/nvim-treesitter-textobjects"

event = "BufRead"
