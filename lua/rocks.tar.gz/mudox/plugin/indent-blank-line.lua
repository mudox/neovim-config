url = "lukas-reineke/indent-blankline.nvim"

event = "BufRead"
