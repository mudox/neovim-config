url = "yamatsum/nvim-nonicons"

after = "nvim-web-devicons"

event = "VimEnter"
