url = "simrat39/rust-tools.nvim"
