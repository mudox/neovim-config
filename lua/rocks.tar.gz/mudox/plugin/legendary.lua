url = "mrjones2014/legendary.nvim"

opt = true -- `PackerLoad` by `mappings.lua`
