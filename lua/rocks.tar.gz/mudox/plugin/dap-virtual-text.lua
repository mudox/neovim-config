url = "theHamsta/nvim-dap-virtual-text"

event = "VimEnter"
