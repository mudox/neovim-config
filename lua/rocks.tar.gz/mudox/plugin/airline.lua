url = "vim-airline/vim-airline"

requires = "vim-airline/vim-airline-themes"

-- event = 'VimEnter'
