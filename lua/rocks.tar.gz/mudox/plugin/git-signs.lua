url = "lewis6991/gitsigns.nvim"

event = "BufRead"
