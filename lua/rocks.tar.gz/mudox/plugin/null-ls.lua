url = "jose-elias-alvarez/null-ls.nvim"

event = "BufRead"
