local ncmd = require("mudox.keymap").ncmd

ncmd("\\sp", "lua require('spectre').open()")
