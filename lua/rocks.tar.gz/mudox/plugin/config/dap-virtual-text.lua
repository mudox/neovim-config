require("nvim-dap-virtual-text").setup {
  highlight_new_as_changed = true,
}
