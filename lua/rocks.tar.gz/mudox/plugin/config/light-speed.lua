local opts = {
  ignore_case = true,
}

require("lightspeed").setup(opts)
