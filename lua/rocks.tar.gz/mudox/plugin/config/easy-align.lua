local k = require("mudox.keymap")

k.nplug("ga", "EasyAlign")
k.xplug("ga", "EasyAlign")
