local project = require("project_nvim")

local opts = {
  silent_chdir = false,
}

project.setup(opts)
