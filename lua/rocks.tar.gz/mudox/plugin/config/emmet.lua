-- vim: fdm=marker fmr=〈,〉

vim.g.user_emmet_leader_key = "<M-,>"

-- Settings 〈
-- see emmet-vim/autoload/emmet.vim, search for `s:emmet_settings`
vim.g.user_emmet_settings = {}
-- 〉

-- Mappings 〈

-- vim.g.user_emmet_expandabbr_key = '<M-,>,'
-- vim.g.user_emmet_expandword_key = '<M-,>;'
-- vim.g.user_emmet_update_tag = '<M-,>u'
-- vim.g.user_emmet_balancetaginward_key = '<M-,>d'
-- vim.g.user_emmet_balancetagoutward_key = '<M-,>D'
-- vim.g.user_emmet_next_key = '<M-,>n'
-- vim.g.user_emmet_prev_key = '<M-,>N'
-- vim.g.user_emmet_imagesize_key = '<M-,>i'
-- vim.g.user_emmet_togglecomment_key = '<M-,>/'
-- vim.g.user_emmet_splitjointag_key = '<M-,>j'
-- vim.g.user_emmet_removetag_key = '<M-,>k'
-- vim.g.user_emmet_anchorizeurl_key = '<M-,>a'
-- vim.g.user_emmet_anchorizesummary_key = '<M-,>A'
-- vim.g.user_emmet_mergelines_key = '<M-,>m'
-- vim.g.user_emmet_codepretty_key = '<M-,>c'

-- 〉
