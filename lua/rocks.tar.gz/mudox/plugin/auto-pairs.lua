url = "windwp/nvim-autopairs"

event = "BufRead"

after = "nvim-cmp"
