url = "windwp/nvim-spectre"

requires = "nvim-lua/plenary.nvim"

keys = { "\\sp" }
