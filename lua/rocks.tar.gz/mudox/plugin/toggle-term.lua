url = "akinsho/toggleterm.nvim"

event = "VimEnter"
