url = "tpope/vim-endwise"

event = { "InsertEnter" }
