url = "stevearc/stickybuf.nvim"

event = "VimEnter"
