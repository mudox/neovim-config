url = "mfussenegger/nvim-dap-python"

event = "VimEnter"

after = "nvim-dap"
