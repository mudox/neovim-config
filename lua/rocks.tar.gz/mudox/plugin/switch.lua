url = "AndrewRadev/switch.vim"

function config()
  vim.g.switch_mapping = "-"
end
