url = "kyazdani42/nvim-web-devicons"

event = "VimEnter"
