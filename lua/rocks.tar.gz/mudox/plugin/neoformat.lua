url = "sbdchd/neoformat"

cmd = { "Neoformat" }

keys = { [[\af]] }
