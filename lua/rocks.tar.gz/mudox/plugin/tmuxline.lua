url = "edkolev/tmuxline.vim"

cmd = { "Tmuxline" }
