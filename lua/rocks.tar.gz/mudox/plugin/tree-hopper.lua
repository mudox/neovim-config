url = "mfussenegger/nvim-ts-hint-textobject"

event = "BufRead"
