-- Automatically generated packer.nvim plugin loader code

if vim.api.nvim_call_function('has', {'nvim-0.5'}) ~= 1 then
  vim.api.nvim_command('echohl WarningMsg | echom "Invalid Neovim version for packer.nvim! | echohl None"')
  return
end

vim.api.nvim_command('packadd packer.nvim')

local no_errors, error_msg = pcall(function()

  local time
  local profile_info
  local should_profile = false
  if should_profile then
    local hrtime = vim.loop.hrtime
    profile_info = {}
    time = function(chunk, start)
      if start then
        profile_info[chunk] = hrtime()
      else
        profile_info[chunk] = (hrtime() - profile_info[chunk]) / 1e6
      end
    end
  else
    time = function(chunk, start) end
  end
  
local function save_profiles(threshold)
  local sorted_times = {}
  for chunk_name, time_taken in pairs(profile_info) do
    sorted_times[#sorted_times + 1] = {chunk_name, time_taken}
  end
  table.sort(sorted_times, function(a, b) return a[2] > b[2] end)
  local results = {}
  for i, elem in ipairs(sorted_times) do
    if not threshold or threshold and elem[2] > threshold then
      results[i] = elem[1] .. ' took ' .. elem[2] .. 'ms'
    end
  end

  _G._packer = _G._packer or {}
  _G._packer.profile_output = results
end

time([[Luarocks path setup]], true)
local package_path_str = "/Users/mudox/.cache/nvim/packer_hererocks/2.1.0-beta3/share/lua/5.1/?.lua;/Users/mudox/.cache/nvim/packer_hererocks/2.1.0-beta3/share/lua/5.1/?/init.lua;/Users/mudox/.cache/nvim/packer_hererocks/2.1.0-beta3/lib/luarocks/rocks-5.1/?.lua;/Users/mudox/.cache/nvim/packer_hererocks/2.1.0-beta3/lib/luarocks/rocks-5.1/?/init.lua"
local install_cpath_pattern = "/Users/mudox/.cache/nvim/packer_hererocks/2.1.0-beta3/lib/lua/5.1/?.so"
if not string.find(package.path, package_path_str, 1, true) then
  package.path = package.path .. ';' .. package_path_str
end

if not string.find(package.cpath, install_cpath_pattern, 1, true) then
  package.cpath = package.cpath .. ';' .. install_cpath_pattern
end

time([[Luarocks path setup]], false)
time([[try_loadstring definition]], true)
local function try_loadstring(s, component, name)
  local success, result = pcall(loadstring(s), name, _G.packer_plugins[name])
  if not success then
    vim.schedule(function()
      vim.api.nvim_notify('packer.nvim: Error running ' .. component .. ' for ' .. name .. ': ' .. result, vim.log.levels.ERROR, {})
    end)
  end
  return result
end

time([[try_loadstring definition]], false)
time([[Defining packer_plugins]], true)
_G.packer_plugins = {
  ["Comment.nvim"] = {
    config = { "\27LJ\2\n;\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0 mudox.plugin.config.comment\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/Comment.nvim",
    url = "https://github.com/numToStr/Comment.nvim"
  },
  ["aerial.nvim"] = {
    config = { "\27LJ\2\n:\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\31mudox.plugin.config.aerial\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/aerial.nvim",
    url = "https://github.com/stevearc/aerial.nvim"
  },
  ["clever-f.vim"] = {
    keys = { { "", "f" }, { "", "F" } },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/clever-f.vim",
    url = "https://github.com/rhysd/clever-f.vim"
  },
  ["coc.nvim"] = {
    config = { "\27LJ\2\nd\2\0\3\0\3\0\0056\0\0\0009\0\1\0'\2\2\0B\0\2\1K\0\1\0Esource /Users/mudox/.config/nvim/lua/mudox/plugin/config/coc.vim\bcmd\bvim\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/coc.nvim",
    url = "https://github.com/neoclide/coc.nvim"
  },
  ["dressing.nvim"] = {
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/dressing.nvim",
    url = "https://github.com/stevearc/dressing.nvim"
  },
  ["emmet-vim"] = {
    config = { "\27LJ\2\n9\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\30mudox.plugin.config.emmet\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/emmet-vim",
    url = "https://github.com/mattn/emmet-vim"
  },
  ["filetype.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/filetype.nvim",
    url = "https://github.com/nathom/filetype.nvim"
  },
  ["impatient.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/impatient.nvim",
    url = "https://github.com/lewis6991/impatient.nvim"
  },
  ["indent-blankline.nvim"] = {
    config = { "\27LJ\2\nE\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0*mudox.plugin.config.indent-blank-line\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/indent-blankline.nvim",
    url = "https://github.com/lukas-reineke/indent-blankline.nvim"
  },
  ["jsonc.vim"] = {
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/jsonc.vim",
    url = "https://github.com/neoclide/jsonc.vim"
  },
  ["lightspeed.nvim"] = {
    config = { "\27LJ\2\n?\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0$mudox.plugin.config.light-speed\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/lightspeed.nvim",
    url = "https://github.com/ggandor/lightspeed.nvim"
  },
  ["lualine.nvim"] = {
    config = { "\27LJ\2\n;\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0 mudox.plugin.config.lualine\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/lualine.nvim",
    url = "https://github.com/nvim-lualine/lualine.nvim"
  },
  ["moonscript-vim"] = {
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/moonscript-vim",
    url = "https://github.com/leafo/moonscript-vim"
  },
  neoformat = {
    commands = { "Neoformat" },
    config = { "\27LJ\2\n=\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\"mudox.plugin.config.neoformat\frequire\0" },
    keys = { { "", "\\af" } },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/neoformat",
    url = "https://github.com/sbdchd/neoformat"
  },
  ["nnn.nvim"] = {
    commands = { "NnnPicker", "NnnExplorer" },
    config = { "\27LJ\2\n7\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\28mudox.plugin.config.nnn\frequire\0" },
    keys = { { "", "<M-/>n" }, { "", "<M-/>N" } },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/nnn.nvim",
    url = "https://github.com/luukvbaal/nnn.nvim"
  },
  ["nvim-base16.lua"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/nvim-base16.lua",
    url = "https://github.com/NvChad/nvim-base16.lua"
  },
  ["nvim-luapad"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/nvim-luapad",
    url = "https://github.com/rafcamlet/nvim-luapad"
  },
  ["nvim-notify"] = {
    config = { "\27LJ\2\n:\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\31mudox.plugin.config.notify\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/nvim-notify",
    url = "https://github.com/rcarriga/nvim-notify"
  },
  ["nvim-spectre"] = {
    config = { "\27LJ\2\n;\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0 mudox.plugin.config.spectre\frequire\0" },
    keys = { { "", "\\sp" } },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/nvim-spectre",
    url = "https://github.com/windwp/nvim-spectre"
  },
  ["nvim-treesitter"] = {
    config = { "\27LJ\2\n?\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0$mudox.plugin.config.tree-sitter\frequire\0" },
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/nvim-treesitter",
    url = "https://github.com/nvim-treesitter/nvim-treesitter"
  },
  ["nvim-treesitter-textobjects"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/nvim-treesitter-textobjects",
    url = "https://github.com/nvim-treesitter/nvim-treesitter-textobjects"
  },
  ["nvim-ts-hint-textobject"] = {
    config = { "\27LJ\2\n?\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0$mudox.plugin.config.tree-hopper\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/nvim-ts-hint-textobject",
    url = "https://github.com/mfussenegger/nvim-ts-hint-textobject"
  },
  ["nvim-ts-rainbow"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/nvim-ts-rainbow",
    url = "https://github.com/p00f/nvim-ts-rainbow"
  },
  ["nvim-web-devicons"] = {
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/nvim-web-devicons",
    url = "https://github.com/kyazdani42/nvim-web-devicons"
  },
  nvim_context_vt = {
    config = { "\27LJ\2\n>\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0#mudox.plugin.config.context-vt\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/nvim_context_vt",
    url = "https://github.com/haringsrob/nvim_context_vt"
  },
  ["packer.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/packer.nvim",
    url = "https://github.com/wbthomason/packer.nvim"
  },
  ["plenary.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/plenary.nvim",
    url = "https://github.com/nvim-lua/plenary.nvim"
  },
  ["popup.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/popup.nvim",
    url = "https://github.com/nvim-lua/popup.nvim"
  },
  ["ron.vim"] = {
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/ron.vim",
    url = "https://github.com/ron-rs/ron.vim"
  },
  ["startuptime.vim"] = {
    commands = { "StartupTime" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/startuptime.vim",
    url = "https://github.com/tweekmonster/startuptime.vim"
  },
  ["stickybuf.nvim"] = {
    config = { "\27LJ\2\n=\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\"mudox.plugin.config.stickybuf\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/stickybuf.nvim",
    url = "https://github.com/stevearc/stickybuf.nvim"
  },
  ["swift.vim"] = {
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/swift.vim",
    url = "https://github.com/keith/swift.vim"
  },
  ["switch.vim"] = {
    config = { "\27LJ\2\n2\0\0\2\0\4\0\0056\0\0\0009\0\1\0'\1\3\0=\1\2\0K\0\1\0\6-\19switch_mapping\6g\bvim\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/switch.vim",
    url = "https://github.com/AndrewRadev/switch.vim"
  },
  ["targets.vim"] = {
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/targets.vim",
    url = "https://github.com/wellle/targets.vim"
  },
  ["telescope-coc.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-coc.nvim",
    url = "https://github.com/fannheyward/telescope-coc.nvim"
  },
  ["telescope-dap.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-dap.nvim",
    url = "https://github.com/nvim-telescope/telescope-dap.nvim"
  },
  ["telescope-file-browser.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-file-browser.nvim",
    url = "https://github.com/nvim-telescope/telescope-file-browser.nvim"
  },
  ["telescope-fzf-native.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-fzf-native.nvim",
    url = "https://github.com/nvim-telescope/telescope-fzf-native.nvim"
  },
  ["telescope-live-grep-raw.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-live-grep-raw.nvim",
    url = "https://github.com/nvim-telescope/telescope-live-grep-raw.nvim"
  },
  ["telescope-packer.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-packer.nvim",
    url = "https://github.com/nvim-telescope/telescope-packer.nvim"
  },
  ["telescope-termfinder.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-termfinder.nvim",
    url = "https://github.com/tknightz/telescope-termfinder.nvim"
  },
  ["telescope-ui-select.nvim"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/telescope-ui-select.nvim",
    url = "https://github.com/nvim-telescope/telescope-ui-select.nvim"
  },
  ["telescope.nvim"] = {
    config = { "\27LJ\2\n=\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\"mudox.plugin.config.telescope\frequire\0" },
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/telescope.nvim",
    url = "https://github.com/nvim-telescope/telescope.nvim"
  },
  ["tmuxline.vim"] = {
    commands = { "Tmuxline" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/tmuxline.vim",
    url = "https://github.com/edkolev/tmuxline.vim"
  },
  ["todo-comments.nvim"] = {
    config = { "\27LJ\2\nA\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0&mudox.plugin.config.todo-comments\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/todo-comments.nvim",
    url = "https://github.com/folke/todo-comments.nvim"
  },
  ["trouble.nvim"] = {
    config = { "\27LJ\2\n;\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0 mudox.plugin.config.trouble\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/trouble.nvim",
    url = "https://github.com/folke/trouble.nvim"
  },
  ultisnips = {
    after = { "vim-snippets" },
    loaded = true,
    only_config = true
  },
  ["vim-easy-align"] = {
    config = { "\27LJ\2\n>\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0#mudox.plugin.config.easy-align\frequire\0" },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/vim-easy-align",
    url = "https://github.com/junegunn/vim-easy-align"
  },
  ["vim-fugitive"] = {
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/vim-fugitive",
    url = "https://github.com/tpope/vim-fugitive"
  },
  ["vim-repeat"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-repeat",
    url = "https://github.com/tpope/vim-repeat"
  },
  ["vim-sandwich"] = {
    config = { "\27LJ\2\ni\2\0\3\0\3\0\0056\0\0\0009\0\1\0'\2\2\0B\0\2\1K\0\1\0Jsource /Users/mudox/.config/nvim/lua/mudox/plugin/config/sandwich.vim\bcmd\bvim\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-sandwich",
    url = "https://github.com/machakann/vim-sandwich"
  },
  ["vim-snippets"] = {
    load_after = {},
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/vim-snippets",
    url = "https://github.com/honza/vim-snippets"
  },
  ["vim-textobj-comment"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-textobj-comment",
    url = "https://github.com/glts/vim-textobj-comment"
  },
  ["vim-textobj-entire"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-textobj-entire",
    url = "https://github.com/kana/vim-textobj-entire"
  },
  ["vim-textobj-indent"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-textobj-indent",
    url = "https://github.com/kana/vim-textobj-indent"
  },
  ["vim-textobj-user"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-textobj-user",
    url = "https://github.com/kana/vim-textobj-user"
  },
  ["vim-tmux-navigator"] = {
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/vim-tmux-navigator",
    url = "https://github.com/christoomey/vim-tmux-navigator"
  },
  ["vim-toml"] = {
    loaded = false,
    needs_bufread = true,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/vim-toml",
    url = "https://github.com/cespare/vim-toml"
  },
  ["vim-unimpaired"] = {
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/vim-unimpaired",
    url = "https://github.com/tpope/vim-unimpaired"
  },
  ["vim-visual-multi"] = {
    keys = { { "n", "<C-n>" }, { "i", "<C-n>" }, { "v", "<C-n>" } },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/vim-visual-multi",
    url = "https://github.com/mg979/vim-visual-multi"
  },
  ["which-key.nvim"] = {
    config = { "\27LJ\2\n=\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\"mudox.plugin.config.which-key\frequire\0" },
    loaded = true,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/start/which-key.nvim",
    url = "https://github.com/folke/which-key.nvim"
  },
  ["zen-mode.nvim"] = {
    config = { "\27LJ\2\n<\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0!mudox.plugin.config.zen-mode\frequire\0" },
    keys = { { "n", "yoz" } },
    loaded = false,
    needs_bufread = false,
    only_cond = false,
    path = "/Users/mudox/.local/share/nvim/site/mdx_nvim_mode/coc/pack/packer/opt/zen-mode.nvim",
    url = "https://github.com/folke/zen-mode.nvim"
  }
}

time([[Defining packer_plugins]], false)
-- Config for: todo-comments.nvim
time([[Config for todo-comments.nvim]], true)
try_loadstring("\27LJ\2\nA\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0&mudox.plugin.config.todo-comments\frequire\0", "config", "todo-comments.nvim")
time([[Config for todo-comments.nvim]], false)
-- Config for: emmet-vim
time([[Config for emmet-vim]], true)
try_loadstring("\27LJ\2\n9\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\30mudox.plugin.config.emmet\frequire\0", "config", "emmet-vim")
time([[Config for emmet-vim]], false)
-- Config for: switch.vim
time([[Config for switch.vim]], true)
try_loadstring("\27LJ\2\n2\0\0\2\0\4\0\0056\0\0\0009\0\1\0'\1\3\0=\1\2\0K\0\1\0\6-\19switch_mapping\6g\bvim\0", "config", "switch.vim")
time([[Config for switch.vim]], false)
-- Config for: vim-sandwich
time([[Config for vim-sandwich]], true)
try_loadstring("\27LJ\2\ni\2\0\3\0\3\0\0056\0\0\0009\0\1\0'\2\2\0B\0\2\1K\0\1\0Jsource /Users/mudox/.config/nvim/lua/mudox/plugin/config/sandwich.vim\bcmd\bvim\0", "config", "vim-sandwich")
time([[Config for vim-sandwich]], false)
-- Config for: aerial.nvim
time([[Config for aerial.nvim]], true)
try_loadstring("\27LJ\2\n:\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\31mudox.plugin.config.aerial\frequire\0", "config", "aerial.nvim")
time([[Config for aerial.nvim]], false)
-- Config for: ultisnips
time([[Config for ultisnips]], true)
try_loadstring("\27LJ\2\n=\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\"mudox.plugin.config.ultisnips\frequire\0", "config", "ultisnips")
time([[Config for ultisnips]], false)
-- Config for: which-key.nvim
time([[Config for which-key.nvim]], true)
try_loadstring("\27LJ\2\n=\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\"mudox.plugin.config.which-key\frequire\0", "config", "which-key.nvim")
time([[Config for which-key.nvim]], false)
-- Config for: nvim-notify
time([[Config for nvim-notify]], true)
try_loadstring("\27LJ\2\n:\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0\31mudox.plugin.config.notify\frequire\0", "config", "nvim-notify")
time([[Config for nvim-notify]], false)
-- Config for: trouble.nvim
time([[Config for trouble.nvim]], true)
try_loadstring("\27LJ\2\n;\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0 mudox.plugin.config.trouble\frequire\0", "config", "trouble.nvim")
time([[Config for trouble.nvim]], false)
-- Config for: lualine.nvim
time([[Config for lualine.nvim]], true)
try_loadstring("\27LJ\2\n;\2\0\3\0\2\0\0046\0\0\0'\2\1\0B\0\2\1K\0\1\0 mudox.plugin.config.lualine\frequire\0", "config", "lualine.nvim")
time([[Config for lualine.nvim]], false)

-- Command lazy-loads
time([[Defining lazy-load commands]], true)
pcall(vim.cmd, [[command -nargs=* -range -bang -complete=file Tmuxline lua require("packer.load")({'tmuxline.vim'}, { cmd = "Tmuxline", l1 = <line1>, l2 = <line2>, bang = <q-bang>, args = <q-args>, mods = "<mods>" }, _G.packer_plugins)]])
pcall(vim.cmd, [[command -nargs=* -range -bang -complete=file Neoformat lua require("packer.load")({'neoformat'}, { cmd = "Neoformat", l1 = <line1>, l2 = <line2>, bang = <q-bang>, args = <q-args>, mods = "<mods>" }, _G.packer_plugins)]])
pcall(vim.cmd, [[command -nargs=* -range -bang -complete=file StartupTime lua require("packer.load")({'startuptime.vim'}, { cmd = "StartupTime", l1 = <line1>, l2 = <line2>, bang = <q-bang>, args = <q-args>, mods = "<mods>" }, _G.packer_plugins)]])
pcall(vim.cmd, [[command -nargs=* -range -bang -complete=file NnnPicker lua require("packer.load")({'nnn.nvim'}, { cmd = "NnnPicker", l1 = <line1>, l2 = <line2>, bang = <q-bang>, args = <q-args>, mods = "<mods>" }, _G.packer_plugins)]])
pcall(vim.cmd, [[command -nargs=* -range -bang -complete=file NnnExplorer lua require("packer.load")({'nnn.nvim'}, { cmd = "NnnExplorer", l1 = <line1>, l2 = <line2>, bang = <q-bang>, args = <q-args>, mods = "<mods>" }, _G.packer_plugins)]])
time([[Defining lazy-load commands]], false)

-- Keymap lazy-loads
time([[Defining lazy-load keymaps]], true)
vim.cmd [[nnoremap <silent> <C-n> <cmd>lua require("packer.load")({'vim-visual-multi'}, { keys = "<lt>C-n>", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[noremap <silent> F <cmd>lua require("packer.load")({'clever-f.vim'}, { keys = "F", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[noremap <silent> \af <cmd>lua require("packer.load")({'neoformat'}, { keys = "\\af", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[noremap <silent> f <cmd>lua require("packer.load")({'clever-f.vim'}, { keys = "f", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[noremap <silent> <M-/>N <cmd>lua require("packer.load")({'nnn.nvim'}, { keys = "<lt>M-/>N", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[noremap <silent> <M-/>n <cmd>lua require("packer.load")({'nnn.nvim'}, { keys = "<lt>M-/>n", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[noremap <silent> \sp <cmd>lua require("packer.load")({'nvim-spectre'}, { keys = "\\sp", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[vnoremap <silent> <C-n> <cmd>lua require("packer.load")({'vim-visual-multi'}, { keys = "<lt>C-n>", prefix = "" }, _G.packer_plugins)<cr>]]
vim.cmd [[inoremap <silent> <C-n> <cmd>lua require("packer.load")({'vim-visual-multi'}, { keys = "<lt>C-n>" }, _G.packer_plugins)<cr>]]
vim.cmd [[nnoremap <silent> yoz <cmd>lua require("packer.load")({'zen-mode.nvim'}, { keys = "yoz", prefix = "" }, _G.packer_plugins)<cr>]]
time([[Defining lazy-load keymaps]], false)

vim.cmd [[augroup packer_load_aucmds]]
vim.cmd [[au!]]
  -- Event lazy-loads
time([[Defining lazy-load event autocommands]], true)
vim.cmd [[au VimEnter * ++once lua require("packer.load")({'dressing.nvim', 'vim-toml', 'swift.vim', 'targets.vim', 'vim-snippets', 'jsonc.vim', 'vim-unimpaired', 'coc.nvim', 'vim-fugitive', 'stickybuf.nvim', 'nvim-web-devicons', 'moonscript-vim', 'telescope.nvim', 'ron.vim'}, { event = "VimEnter *" }, _G.packer_plugins)]]
vim.cmd [[au BufRead * ++once lua require("packer.load")({'Comment.nvim', 'vim-easy-align', 'nvim_context_vt', 'lightspeed.nvim', 'indent-blankline.nvim', 'nvim-treesitter', 'nvim-ts-hint-textobject'}, { event = "BufRead *" }, _G.packer_plugins)]]
time([[Defining lazy-load event autocommands]], false)
vim.cmd("augroup END")
if should_profile then save_profiles() end

end)

if not no_errors then
  error_msg = error_msg:gsub('"', '\\"')
  vim.api.nvim_command('echohl ErrorMsg | echom "Error in packer_compiled: '..error_msg..'" | echom "Please check your config for correctness" | echohl None')
end
